from scrapy import Spider
from scrapy.http import Request

from FirmCrawler.items import FirmcrawlerItem
import time

import json
import scrapy
import urlparse


from proxy_ips import proxy_ip
import random


def random_proxy_ip():
    proxy_ip_index = random.randint(0,len(proxy_ip)-1)
    #res = {'http':proxy_ip[proxy_ip_index]}
    res = proxy_ip[proxy_ip_index]
    return res
class ZyXELSpider(Spider):
    name = "zyxel"
    allowed_domains = ["zyxel.com"]
    start_urls = ["http://www.zyxel.com/us/en/support/download_landing.shtml"]

    custom_settings = {"CONCURRENT_REQUESTS": 3}

    def parse(self, response):
        print "use ip"
        iprand = random_proxy_ip()
        print "random proxy:", iprand
        request = scrapy.Request(response.url, callback=self.parse_page, meta={'proxy':'http://'+iprand})
        yield request

    def parse_page(self, response):
        print "pass ip"
        script = json.loads(response.xpath(
            "//div[@id='searchDropUlWrap']/script//text()").extract()[0].split('=')[2].strip()[0: -1])
        for entry in script:
            yield Request(
                url=urlparse.urljoin(
                    response.url, "/us/en/support/SearchResultTab.shtml?c=us&l=en&t=dl&md=%s&mt=Firmware&mt=MIBFile" % script[entry][1]),
                headers={"Referer": response.url},
                meta={"product": script[entry][1]},
                callback=self.parse_product)

    def parse_product(self, response):
        mib = None

        if not response.body:
            return

        for entry in reversed(response.xpath("//table/tbody/tr")):
            if entry.xpath("./td[contains(@class, 'versionTd')]/select"):
                for i in range(
                        0, len(entry.xpath("./td[contains(@class, 'versionTd')]/select/option"))):
                    desc = entry.xpath(
                        "./td[contains(@class, 'typeTd')]/span/text()").extract()

                    if "firmware" in desc:
                        date = entry.xpath(
                            "./td[contains(@class, 'dateTd')]/span/text()").extract()[i]
                        ver = entry.xpath(
                            "./td[contains(@class, 'versionTd')]/select/option/text()").extract()[i]
                        href = entry.xpath(
                            "./td[contains(@class, 'downloadTd')]/div/a[1]/@data-filelink").extract()[i]

                        item = FirmcrawlerItem()
                        item["productVersion"] = ver
                        item["publishTime"] = date
                        item["productClass"] = ""
                        item["productModel"] = response.meta["product"]
                        item["description"] = str().join(desc).strip().replace(" ","")
                        item["url"] = href
                        item["firmwareName"] = href.split('/')[-1]
                        item["crawlerTime"] = time.strftime("%Y-%m-%d %H:%M:%S")
                        item["manufacturer"] = "zyxel"
                        yield item
                        print "firmware name:", item["firmwareName"]


            else:
                desc = entry.xpath(
                    "./td[contains(@class, 'typeTd')]//text()").extract()

                if "firmware" in desc:
                    date = entry.xpath(
                        "./td[contains(@class, 'dateTd')]//text()").extract()
                    ver = entry.xpath(
                        "./td[contains(@class, 'versionTd')]//text()").extract()
                    href = entry.xpath(
                        "./td[contains(@class, 'downloadTd')]//a/@data-filelink").extract()[0]

                    item = FirmcrawlerItem()
                    item["productVersion"] = ver
                    item["publishTime"] = date
                    item["productClass"] = ""
                    item["productModel"] = response.meta["product"]
                    item["description"] = str().join(desc).strip().replace(" ","")
                    item["url"] = href
                    item["firmwareName"] = href.split('/')[-1]
                    item["crawlerTime"] = time.strftime("%Y-%m-%d %H:%M:%S")
                    item["manufacturer"] = "zyxel"
                    yield item
                    print "firmware name:", item["firmwareName"]


