# -*- coding: UTF-8 -*-
__author__ = "zhaoweiwei"
__time__ = "2017.04.13"
from sets import Set
from scrapy.spiders import Spider
import scrapy
import FirmCrawler.items as MI
import re
import urlparse
import urllib2
import time


class xmSpider(Spider):
    name = "xm"
    timeout = 12
    trytimes = 3
    start_urls = [
        "http://www.xiongmaitech.com/index.php/service/down/13"
    ]
    # must be lower character
    typefilter = ["txt", "pdf"]
    allsuffix = Set()
    '''
    XMJP(170)----3 page
    http://www.xiongmaitech.com/index.php/service/down_detail1/13/170
    IPC(2)-----11 page
    http://www.xiongmaitech.com/index.php/service/down_detail1/13/2
    DVR(1)------10 page
    http://www.xiongmaitech.com/index.php/service/down_detail1/13/1
    NVR(4)------ 4 page
    http://www.xiongmaitech.com/index.php/service/down_detail1/13/4
    '''
    def parse(self, response):
        for p in xrange(1,3+1):
            urls = "http://www.xiongmaitech.com/index.php/service/down_detail1/13" + "/170/" + str(p)
            request = scrapy.Request(urls, callback=self.parse_lists)
            request.meta["prototype"] = MI.FirmcrawlerItem()
            request.meta["prototype"]["manufacturer"] = "xm"
            yield request

        # for p in xrange(1,11+1):
        #     urls = "http://www.xiongmaitech.com/index.php/service/down_detail1/13" + "/2/" + str(p)
        #     request = scrapy.Request(urls, callback=self.parse_list)
        #     yield request
        #
        # for p in xrange(1, 10 + 1):
        #     urls = "http://www.xiongmaitech.com/index.php/service/down_detail1/13" + "/1/" + str(p)
        #     request = scrapy.Request(urls, callback=self.parse_list)
        #     yield request
        #
        # for p in xrange(1, 4 + 1):
        #     urls = "http://www.xiongmaitech.com/index.php/service/down_detail1/13" + "/4/" + str(p)
        #     request = scrapy.Request(urls, callback=self.parse_list)
        #     yield request

    def parse_lists(self, response):
        print "response url:",response.url

        tables = response.xpath('//div[@class="w1000"]/div/div[2]/ul/li//a/@href').extract()
                                #'    div[@class="down_nav3"]//a/@href').extract()
        print "table len:",len(tables)
        if str(len(tables)) == "0":
            print "deng 0"
            urls = response.url
            request = scrapy.Request(urls, callback=self.parse_lists)
            request.meta["prototype"] = response.meta["prototype"]
            yield request
            print "call self"
        else:
            print "bu 0"
            for t in tables:
                absurl = urlparse.urljoin(response.url, t)
                print "absurl:",absurl
                request = scrapy.Request(absurl, callback=self.parse_page)
                yield request


    def parse_page(self, response):
        urls = response.xpath('//div[@class="down1-ccont"]//a[1]/@href').extract() #soho pan url
        if urls:

            print "urls:",urls[0]
            infos = response.xpath('//div[@class="down-p2"]/p/text()').extract()[0]
            infos = unicode.encode(infos, encoding='utf8')
            print "infos:",infos
            if "最新固件" in infos:
                model = infos.split("(")[-1].split(")")[0]
                version = response.xpath('//div[@class="down1-ccont"]/p[1]/text()').extract()[0]
                print "dn version:",version
                version = version.split(":")[-1]
            else:
                version = infos.rsplit("_",1)[-1]
                model = infos.rsplit("_",1)[0].split(")")[-1]


            item = MI.FirmcrawlerItem()
            item["productVersion"] = version
            item["productClass"] = "Camera"
            item["productModel"] = model
            item["description"] = ""
            item["url"] = urls[0]
            item["firmwareName"] = item["url"].split("/")[-1]
            item["crawlerTime"] = time.strftime("%Y-%m-%d %H:%M:%S")
            item["manufacturer"] = "xm"
            #yield item
            print "firmware name:", item["firmwareName"]



