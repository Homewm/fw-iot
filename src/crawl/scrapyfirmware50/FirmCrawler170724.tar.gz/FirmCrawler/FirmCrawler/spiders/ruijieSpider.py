# -*- coding: UTF-8 -*-
__author__ = "zhaoweiwei"
__time__ = "2017.04.20"
from sets import Set
from scrapy.spiders import Spider
import scrapy
import FirmCrawler.items as MI
import re
import urlparse
import urllib2
import time
from selenium import webdriver
from selenium.common.exceptions import *
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC

class ruijieSpider(Spider):
    name = "ruijie"
    timeout = 12
    trytimes = 3
    start_urls = [
        #"http://www.ruijie.com.cn/fw/rj/"
        "http://www.ruijie.com.cn/fw/rj-ss-%E8%B7%AF%E7%94%B1%E5%99%A8/"
    ]
    # must be lower character
    typefilter = ["txt", "pdf"]
    allsuffix = Set()
    def parse(self, response):


        browser = webdriver.Chrome(executable_path="/usr/bin/google-chrome-stable")
        # browser.implicitly_wait(ruijieSpider.timeout)
        #browser.set_page_load_timeout(ruijieSpider.timeout)
        #browser.set_window_size(1920, 1080)
        try:
            browser.get(response.url)
            print "zhengque huoqu lianjie"
        except TimeoutException:
            print "pao yi cheng"
            browser.save_screenshot('/home/cy/aaa/screenshot1.png')
        try:
            WebDriverWait(browser, ruijieSpider.timeout).until(EC.presence_of_element_located((By.ID, "divSearchResult")))
            print "zhaodao id"
        except:
            print "pao yi cheng diaoyong"
            browser.save_screenshot('/home/cy/aaa/screenshot2.png')
        # browser.find_element_by_id('txtSoftSearchValue').send_keys('%E4%BA%A4%E6%8D%A2%E6%9C%BA')
        # js = "document.getElementById('page_size').options[1].text='1000'"
        # browser.execute_script(js);
        print "execute finish"
        browser.close()


        # for i in xrange(1,18+1):
        #     url = "http://service.fastcom.com.cn/download-list.html?classTip=software&p=%s&o=1&ajax=True&paging=False" %i
        #     print "url:",url
        #     request = scrapy.Request(url, callback=self.parse_list)
        #     request.meta["prototype"] = MI.FirmcrawlerItem()
        #     request.meta["prototype"]["manufacturer"] = "fast"
        #     yield request

    # def parse_list(self, response):
    #     tables = response.xpath('//div[@class="container table-container"]//a/@href').extract()
    #     for t in tables:
    #         url = urlparse.urljoin(response.url,t)
    #         request = scrapy.Request(url, callback=self.parse_page)
    #         request.meta["prototype"] = MI.FirmcrawlerItem()
    #         request.meta["prototype"]["manufacturer"] = "fast"
    #         yield request
    # def parse_page(self,response):
    #     prototype = response.meta['prototype']
    #     item = MI.FirmcrawlerItem(prototype)






#
# "http://www.ruijie.com.cn/yx/cp-ly-hxly/rsrm/"
#
#
# "www.ruijie.com.cn/fw/rj-ss-路由器/"
# "http://www.ruijie.com.cn/fw/rj-ss-%E4%BA%A4%E6%8D%A2%E6%9C%BA/"