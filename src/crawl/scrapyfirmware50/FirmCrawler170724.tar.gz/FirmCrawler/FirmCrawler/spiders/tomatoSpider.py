# -*- coding: UTF-8 -*-
from sets import Set
import logging
from scrapy.spiders import Spider
from scrapy.http import Request
from selenium import webdriver
from selenium.common.exceptions import *
from selenium.webdriver.support.ui import WebDriverWait
import FirmCrawler.items as MI
import time
import re
class tomatoSpider(Spider):
    name = "tomatobb"
    timeout = 8
    trytimes = 3
    start_urls = ["http://tomato.groov.pl/download"]
    handle_httpstatus_list = [404]
    # must be lower character
    suffix = ["bin", "elf", "fdt", "imx", "chk", "trx","zip","gz"]
    allsuffix = Set()
    def start_requests(self):
        for url in tomatoSpider.start_urls:
            yield Request(url, meta={"build": "build", "product": "product"})
    def _loadcomplete(self, x):
        if len(x.find_elements_by_xpath("html/body/div/div/ul/li")) == self.finds:
          return True
        self.finds = len(x.find_elements_by_xpath("html/body/div/div/ul/li"))
        return False
    def parse(self, response):
        browser = webdriver.PhantomJS(executable_path="/home/cy/appHome/phantomjs-2.1.1-linux-x86_64/bin/phantomjs")
        browser.implicitly_wait(tomatoSpider.timeout)
        browser.set_page_load_timeout(tomatoSpider.timeout)
        t = tomatoSpider.trytimes
        try:
            browser.get(response.url)
        except TimeoutException:
            pass
        self.dirs = Set()
        for i in browser.find_elements_by_xpath('//li[@class="item folder"]/a'):
            # print i.get_attribute("href")
            self.dirs.add(i.get_attribute("href"))

            print len(self.dirs)
        # print self.dirs
        # return
        logging.log(logging.INFO, "Root Fetch:%d", len(self.dirs))
        # items = Set()
        while len(self.dirs):
            d = self.dirs.pop()
            t = tomatoSpider.trytimes
            while True:
                try:
                    browser.get(d)
                    self.finds = -1
                    try:
                        WebDriverWait(browser, tomatoSpider.timeout).until(
                            self._loadcomplete)
                    except TimeoutException:
                        pass
                    lines = browser.find_elements_by_xpath( "//li")
                    logging.log(logging.INFO, "Fetch:%s,len:%d", d, len(lines))
                    for l in lines:
                        if l.get_attribute("class") == "item folder":
                            sxx = l.find_element_by_xpath('./a')  #'//li[@class="item folder"]/a'
                            self.dirs.add(sxx.get_attribute("href"))
                            #print"$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$"
                        if l.get_attribute("class") == "item file":
                            print "............begin  file.............."
                            sx = l.find_element_by_xpath("./a")
                            link = sx.get_attribute("href")
                            print link


                            filenamee = sx.find_element_by_xpath("./span[@class='label']").text
                            #print "##########################################"
                            print filenamee
                            published = sx.find_element_by_xpath("./span[@class='date']").text
                            # size = sx.find_element_by_xpath("./span[@class='size']").text



                            filename1 = filenamee.split("-")
                            print filename1


                            filetype = filenamee.rsplit(".", 1).pop().strip().lower()
                            print "filetype:%s"%filetype
                            tomatoSpider.allsuffix.add(filetype)
                            xun = 10
                            # print "FileType",filetype
                            if filetype in tomatoSpider.suffix and 'tomato' in filename1:   #用tomato替换FIRMWARE
                            #if xun > 0:
                                print"*********************************************"
                                item = MI.FirmcrawlerItem()
                                #item["Info"] = {}
                                item["ProductVersion"]=""
                                item["PackedTime"]=""
                                item["ProductClass"]="Router"
                                #item["Info"]["Size"]=""
                                item["ProductModel"]=""
                                item["Description"]=""
                                item["Manufacturer"] = "Tomato"
                                item["URL"] = link
                                item["FirmwareName"] = filenamee


                                try:
                                    aaa= link.split("/")
                                    item["ProductModel"] = aaa[4]
                                    item["Description"]=aaa[4]+"/"+aaa[5]
                                except:
                                    pass

                                item["PackedTime"] = "" #l.find_element_by_xpath(
                                    #  "td[3]").text
                                item["PublishTime"] = published             # HOUMIANJIA
                                a = item["PublishTime"]

                                #because the most of version are 1.28,so we abandon it
                                # patt = re.compile(r'([1-9]\.)[0-9]+')
                                # patts = patt.search(filenamee)
                                # if patts:
                                #     item["ProductVersion"] = patts.group()

                                try:

                                    array=time.strptime(a,u"%Y-%m-%d %H:%M")
                                    item["PublishTime"] = time.strftime("%Y-%m-%d",array)
                                except:
                                    print"**********************format errror***********************"


                                print"#############################**************************"
                                yield item
                                print "item   bei  cun  jin  qu"

                except Exception, e:
                    t -= 1
                    if t == 0:
                        logging.exception(e)
                        break
                    continue
                else:
                    break
        logging.log(logging.CRITICAL, "AllSuffix: %s",
                    str(tomatoSpider.allsuffix))
        logging.log(logging.CRITICAL, "ParseSuffix: %s",
                    str(tomatoSpider.suffix))
        #browser.quit()
        browser.close()
        # return items

