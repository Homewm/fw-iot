from scrapy import Spider
from scrapy.http import Request

from FirmCrawler.items import FirmcrawlerItem
from FirmCrawler.loader import FirmwareLoader
import urllib2
import time
class foscamSpider(Spider):
    name = "foscam"
    allowed_domains = ["foscam.com"]
    start_urls = [
        "http://www.foscam.com/download-center/firmware-downloads.html"]
    timeout = 12

    def start_requests(self):
        for url in self.start_urls:
            yield Request(url, cookies={'loginEmail': "@.com"}, dont_filter=True)

    def parse(self, response):
        for i in range(0, len(response.xpath("//div[@id='main_right']/span[1]/p")), 7):
            prods = response.xpath("//div[@id='main_right']/span[1]//p[%d]/text()" % (i + 2)).extract()[0].split("\r\n")

            for product in [x for x in prods]:
                item = FirmcrawlerItem()
                item["productVersion"] = response.xpath('//div[@id="main_right"]/span[1]//p[%d]/text()' % (i + 3)).extract().pop()
                item["productModel"] = product
                item["description"] = ""
                item["productClass"] = "camera"  # more class
                item["url"] = response.xpath('//div[@id="main_right"]/span[1]//p[%d]/a/@href' % (i + 7)).extract().pop()
                item["firmwareName"] = item["url"].split('/')[-1]
                item["crawlerTime"] = time.strftime("%Y-%m-%d %H:%M:%S")
                item["manufacturer"] = "foscam"
                # invoking the network
                try:
                    res = urllib2.urlopen(urllib2.Request(
                        item["url"], None), timeout=foscamSpider.timeout)
                    modfile = res.headers["last-modified"]
                    array = time.strptime(modfile, u"%a, %d %b %Y %H:%M:%S GMT")
                    item["publishTime"] = time.strftime("%Y-%m-%d", array)
                except Exception, e:
                    item["publishTime"] = ""
                    print e


                yield item
                print "firmware name:",item["firmwareName"]

        for i in range(0, len(response.xpath("//div[@id='main_right']/span[2]/p")), 5):
            prods = response.xpath("//div[@id='main_right']/span[2]//p[%d]/text()" % (i + 2)).extract()[0].split(",")

            for product in [x for x in prods]:
                item = FirmcrawlerItem()
                item["productVersion"] = response.xpath(
                    '//div[@id="main_right"]/span[2]//p[%d]/text()' % (i + 3)).extract().pop()
                item["productModel"] = product
                item["description"] = ""
                item["productClass"] = "camera"  # more class
                item["url"] = response.xpath('//div[@id="main_right"]/span[2]//p[%d]/a/@href' % (i + 5)).extract().pop()
                item["firmwareName"] = item["url"].split('/')[-1]
                item["crawlerTime"] = time.strftime("%Y-%m-%d %H:%M:%S")
                item["manufacturer"] = "foscam"
                # invoking the network
                try:
                    res = urllib2.urlopen(urllib2.Request(
                        item["url"], None), timeout=foscamSpider.timeout)
                    modfile = res.headers["last-modified"]
                    array = time.strptime(modfile, u"%a, %d %b %Y %H:%M:%S GMT")
                    item["publishTime"] = time.strftime("%Y-%m-%d", array)
                except Exception, e:
                    item["publishTime"] = ""
                    print e
                yield item
                print "firmware name:", item["firmwareName"]
