from scrapy import Spider
from scrapy.http import FormRequest

from FirmCrawler.items import FirmcrawlerItem
from FirmCrawler.loader import FirmwareLoader
import time

import json

class BuffaloSpider(Spider):
    name = "buffalo"
    allowed_domains = ["buffalotech.com", "cdn.cloudfiles.mosso.com"]
    start_urls = ["http://www.buffalotech.com/support-and-downloads/downloads"]

    def parse(self, response):
        script = ''.join(response.xpath("//div[@id='page_stuff']/script/text()").extract()).split('\"')

        for product in script:
            if ',' not in product and ' ' not in product:
                model = product.replace("\\", "")

                yield FormRequest.from_response(response,
                                                formname="form_downloads_search",
                                                formdata={"search_model_number": model},
                                                meta={"product": model},
                                                headers={"Referer": response.url, "X-Requested-With": "XMLHttpRequest"},
                                                callback=self.parse_product)

    def parse_product(self, response):
        print "url:",response.url
        # json_response = json.loads(response.body_as_unicode())
        #
        # if json_response["success"]:
        #     for prod in json_response["product_downloads"]:
        #         product = json_response["product_downloads"][prod]
        #         for link in product.get("downloads", {}).get(
        #                 "69", {}).get("files", {}):
        #             item = FirmcrawlerItem()
        #             item["manufacturer"] = "buffalo"
        #
        #             item["crawlerTime"] = time.strftime("%Y-%m-%d %H:%M:%S")
        #             item["url"] = link["link_url"]
        #             item["firmwareName"] = item["url"].split('/')[-1]
        #             item["description"] = link["notes"]
        #             item["productClass"] = ""
        #             item["productVersion"] = ""
        #             item["publishTime"] = link["date"]
        #             item["productModel"] = response.meta["product"]
        #             print "firmware name:", item["url"]
        #             yield item
