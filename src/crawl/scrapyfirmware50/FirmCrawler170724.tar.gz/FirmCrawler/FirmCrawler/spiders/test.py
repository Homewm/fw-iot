# import urllib2
# import re
#
# # "ftp://ftp2.zyxel.com/"
# # "ftp://ftp2.zyxel.com/AMG1001-T10A/"
# def getHtml(url):
#   response = urllib2.urlopen(url)
#   html = response.read()
#   return html
# def getfile(html):
#   # reg = r'src="(.+?\.jpg)" pic_ext'
#   reg = r'<a class="dir" href="(.*?)"'
#   # re.S mean multi-matching
#   # filere = re.compile('<a class="dir" href="(.*?)"', re.S)
#   filere = re.search(reg,html)
#   # filelist = re.findall(filere,html)
#   print "filelist len:",len(filere)
#
# req = urllib2.Request('ftp://ftp2.zyxel.com/AMG1001-T10A/')
# html = getHtml(req)
#
# print html
# print "getfile,",getfile(html)
#_*_ coding :utf-8 _*_
import os
from ftplib import FTP


def FtpDownLoad(ftpFile, savePath, user="", pwd=""):
    dirs = str(ftpFile).split("/")
    if len(dirs) < 4:
        return False
    server = dirs[2]
    srcFile = ""
    for item in dirs[3:]:
        srcFile += "/" + str(item)
    try:
        ftp = FTP()
        ftp.connect(server, '21')
        ftp.login(user, pwd)
        ftp.cwd(os.path.dirname(srcFile).lstrip("/"))
        file_handler = open(savePath,'wb')
        ftp.retrbinary('RETR %s' % os.path.basename(srcFile),file_handler.write)
        file_handler.close()
        ftp.quit()
    except:
        print "YICHANG"
FtpDownLoad('ftp://ftp2.zyxel.com/AMG1001-T10A/','/home/cy/aaa')
