# -*- coding: UTF-8 -*-
__author__ = "zhaoweiwei"
__time__ = "2017.04.20"
from sets import Set
from scrapy.spiders import Spider
import scrapy
import FirmCrawler.items as MI
import re
import urlparse
import urllib2
import time
from selenium import webdriver
from selenium.common.exceptions import *
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC


timeout = 10
browser = webdriver.PhantomJS(executable_path="/home/cy/appHome/phantomjs-2.1.1-linux-x86_64/bin/phantomjs")
browser.implicitly_wait(timeout)
browser.set_page_load_timeout(timeout)
class phicommSpider(Spider):
    name = "phicomm"
    timeout = 20
    trytimes = 3
    start_urls = ["http://www.phicomm.com/cn/support.php"]
    # must be lower character
    typefilter = ["txt", "pdf"]
    allsuffix = Set()
    def parse(self, response):

        # 技术支持 > 家庭网络产品 > 软件下载
        for i in xrange(1,1+1):#11+1
            url = "http://www.phicomm.com/cn/support.php/Soho/software_support/t/sm/p/%s.html" %i
            print "url:",url
            request = scrapy.Request(url, callback=self.parse_list)
            request.meta["prototype"] = MI.FirmcrawlerItem()
            request.meta["prototype"]["manufacturer"] = "PHICOMM"
            request.meta["prototype"]["productClass"] = "Router"
            yield request

    def parse_list(self, response):
        tables = response.xpath('//div[@class="tabCon"]/table/tr[position()>1]')
        print "table len:",len(tables)
        try:
            browser.get(response.url)
            print "get url"
        except TimeoutException:
            print "not get url"
            browser.save_screenshot('/home/cy/aaa/screenshot5.png')
            pass

        try:

            WebDriverWait(browser, phicommSpider.timeout).until(EC.presence_of_element_located((By.CLASS_NAME, "tabCon")))
            print "zhengque dnegdai "
        except:
            print "dengdai cuowu"

        items = browser.find_elements_by_xpath('//div[@class="tabCon"]/table/tr[position()>1]')
        print "item len!! :",len(items)
        browser.close()
        # for t in tables:
        #
        #     url = urlparse.urljoin(response.url,t)
        #     request = scrapy.Request(url, callback=self.parse_page)
        #     request.meta["prototype"] = MI.FirmcrawlerItem()
        #     request.meta["prototype"]["manufacturer"] = "fast"
        #     yield request




# 'home network product'
# "http://www.phicomm.com/cn/support.php/Soho/software_support/t/sm/p/2.html"
# 'shutong'
# "http://www.phicomm.com/cn/support.php/Ent/software_support/t/sm/p/2.html"