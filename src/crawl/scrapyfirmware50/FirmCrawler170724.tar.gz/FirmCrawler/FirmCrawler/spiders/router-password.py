# -*- coding: UTF-8 -*-
__author__ = "zhaoweiwei"
__time__ = "2017.03.24"
from sets import Set
from scrapy.spiders import Spider
import scrapy
import FirmCrawler.items as MI
import re
import time
import urlparse
import codecs
file_path = "/home/cy/routerpasswd"
class OpenwrtSpider(Spider):
    name = "routerpassword"
    allowed_domains = ["portforward.com"]
    start_urls = [
        "https://portforward.com/router-password/"

    ]
    timeout = 8
    trytimes = 3

    def parse(self, response):

        lists = response.xpath('//div[@id="double_column_data"]/div[position()>1]/div/a/@href').extract()
        for t in lists:
            urlabs = urlparse.urljoin(response.url,t)
            request = scrapy.Request(urlabs, callback=self.parse_list)
            yield request
    def parse_list(self,response):
        tables = response.xpath('//table[@class="dptable"]/tr[position()>2]/td[3]/text()').extract()
        fp = codecs.open(file_path, mode='a', encoding='utf-8')
        print response.url
        for t in tables:
            print t
            fp.write(t + "\n")
        fp.close()


